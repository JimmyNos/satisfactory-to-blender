import bpy
from mathutils import Quaternion
from pathlib import Path
import satisfactory_save as s

def vector3f_to_tuple(v: s.FVector3f):
    return v.X, v.Y, v.Z

def quat4f_to_euler_tuple(q: s.FQuat4f):
    quat = Quaternion((q.W, q.X, q.Y, q.Z))
    euler = quat.to_euler('XYZ')
    return euler.x, euler.y, euler.z
    #return q.W, q.X, q.Y, q.Z

def read_transform3f(t: s.FTransform3f):
    return vector3f_to_tuple(t.Translation), quat4f_to_euler_tuple(t.Rotation), vector3f_to_tuple(t.Scale3D)

def create_points(name, verts, rotations, scales):
    mesh = bpy.data.meshes.new(f'{name}_Points')
    mesh.from_pydata(verts, [], [])
    obj = bpy.data.objects.new(f"{name}_Points", mesh)
    bpy.context.collection.objects.link(obj)

    mesh.attributes.new("rotation", 'FLOAT_VECTOR', 'POINT')
    flat_rot = [c for vec in rotations for c in vec]
    print(flat_rot)
    mesh.attributes["rotation"].data.foreach_set("vector", flat_rot)

    mesh.attributes.new("scale", 'FLOAT_VECTOR', 'POINT')
    flat_scale = [c for vec in scales for c in vec]
    mesh.attributes["scale"].data.foreach_set("vector", flat_scale)
    
    obj.scale = (0.01, -0.01, 0.01)

# Open save file
save = s.SaveGame(Path('save_path'))

# Add instances of regular objects
#class_constructor = '/Game/FactoryGame/Buildable/Factory/ConstructorMk1/Build_ConstructorMk1.Build_ConstructorMk1_C'
#if not save.isObjectClass(class_constructor):
#    raise RuntimeError('Class name not found!')
#objects = save.getObjectsByClass(class_constructor)
#
#verts, rotations, scales = map(list, zip(*(read_transform3f(obj.Header.Transform) for obj in objects)))
#create_points('Build_ConstructorMk1_C', verts, rotations, scales)

# Add instances of lightweight buildables
#lbs = save.getObjectsByPath('Persistent_Level:PersistentLevel.LightweightBuildableSubsystem')[0].Object
#class_foundation = '/Game/FactoryGame/Buildable/Building/Foundation/ConcreteSet/Build_Foundation_Concrete_8x4.Build_Foundation_Concrete_8x4_C'
#instance_data_list = lbs.mBuildableClassToInstanceArray[s.FObjectReferenceDisc('', class_foundation)]

#verts, rotations, scales = map(list, zip(*(read_transform3f(i.Transform) for i in instance_data_list)))
#create_points('Build_Foundation_Concrete_8x4_C', verts, rotations, scales)


all_classes = set()

for obj in save.allSaveObjects():
    hdr = obj.Header

    cls = None

    # Case 1: Nested ObjectHeader
    if hasattr(hdr, "ObjectHeader"):
        oh = hdr.ObjectHeader
        if hasattr(oh, "ClassName"):
            cls = oh.ClassName

    # Case 2: Direct on header
    elif hasattr(hdr, "ObjectClass"):
        cls = hdr.ObjectClass

    elif hasattr(hdr, "ClassName"):
        cls = hdr.ClassName

    if cls:
        all_classes.add(cls)

unknown_structures = 0

for obj in save.allSaveObjects():
    hdr = obj.Header

    if not (
        hasattr(hdr, "ObjectHeader") or
        hasattr(hdr, "ObjectClass") or
        hasattr(hdr, "ClassName")
    ):
        unknown_structures += 1
        
factory_classes = [
    cls for cls in all_classes
    if cls.startswith('/Game/FactoryGame/Buildable/Factory/')
    and '.Build_' in cls
    and cls.endswith('_C')
]

# exporting factory buildables
for cls in factory_classes:
    if not save.isObjectClass(cls):
        continue

    objs = save.getObjectsByClass(cls)
    if not objs:
        continue

    verts, rotations, scales = map(
        list,
        zip(*(read_transform3f(obj.Header.Transform) for obj in objs))
    )

    name = cls.split('.')[-1]
    create_points(name, verts, rotations, scales)

    print(f"Processed {name}: {len(objs)} instances")

#print("Unknown header types:", unknown_structures)

# exporting lightweight buildables
lbs = save.getObjectsByPath('Persistent_Level:PersistentLevel.LightweightBuildableSubsystem')[0].Object
map_ref = lbs.mBuildableClassToInstanceArray

keys = list(map_ref.Keys)

for class_ref in keys:

    class_path = class_ref.PathName

    if not class_path:
        continue

    if '/Game/FactoryGame/Buildable/Building/' not in class_path:
        continue
    
    instance_data_list = map_ref[class_ref]
    #print(instance_data_list)
    
    if not instance_data_list:
        continue

    verts, rotations, scales = map(
        list,
        zip(*(read_transform3f(i.Transform) for i in instance_data_list))
    )
    #print(rotations)
    
    name = class_path.split('.')[-1]
    
    create_points(name, verts, rotations, scales)

    print(f"{name}: {len(instance_data_list)}")